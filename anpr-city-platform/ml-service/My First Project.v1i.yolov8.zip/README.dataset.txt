# My First Project > 2026-09-04 5:43pm
https://universe.roboflow.com/navdeep-chaurasia/my-first-project-sfloy

Provided by a Roboflow user
License: CC BY 4.0

